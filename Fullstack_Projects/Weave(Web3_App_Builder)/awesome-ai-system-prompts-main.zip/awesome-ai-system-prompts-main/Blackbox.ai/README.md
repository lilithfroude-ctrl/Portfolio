extractec from ~/.vscode/extensions/blackboxapp.blackboxagent-3.1.36/dist using extraction.py
