Claude Code 

npm init
npm install @anthropic-ai/claude-code

and find cli.js inside /node_modules/@anthropic-ai/claude-code


-
ClearTool.js - conversation summarization tool to compress context
MemoryTool.js - markdown persistent storage
EditTool.js - write/edit/update files
???