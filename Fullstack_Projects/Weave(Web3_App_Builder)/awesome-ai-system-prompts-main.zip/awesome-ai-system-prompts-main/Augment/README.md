To get more:

install Augment extension https://www.augmentcode.com/

then inside browsing ~/.vscode/extensions/augment.vscode-augment-*
find out/extension.js